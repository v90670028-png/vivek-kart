import {supabase} from "@/lib/supabase";
export default async function Admin(){
 const {data:products}=await supabase().from("products").select("id,name,supplier_price,selling_price,active").order("created_at",{ascending:false});
 return <main className="wrap"><h1>VivekKart Admin</h1><p className="muted">Supplier price is private. Selling price is shown to customers.</p>
 <table className="table"><thead><tr><th>Product</th><th>Supplier</th><th>Selling</th><th>Gross margin</th><th>Status</th></tr></thead>
 <tbody>{(products||[]).map(p=><tr key={p.id}><td>{p.name}</td><td>₹{p.supplier_price}</td><td>₹{p.selling_price}</td><td>₹{p.selling_price-p.supplier_price}</td><td>{p.active?"Active":"Hidden"}</td></tr>)}</tbody></table></main>}